import geopandas as gpd

class reproject:
    
    def __init__(self, source, targetcrs, finalshp):
        self.source = source
        self.targetcrs = targetcrs
        self.finalshp = finalshp
        
    def read_df(self):
        self.source_df = gpd.read_file(self.source)
        
    def project(self):
        final = self.source_df.to_crs(self.targetcrs)
        return final.to_file(self.finalshp)
    
    def runproject(self):
        self.read_df()
        self.project()
        