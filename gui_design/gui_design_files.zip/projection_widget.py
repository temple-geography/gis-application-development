from gui_reproject import Ui_rproject
import reproject_script
from PyQt5 import QtWidgets as qtw
from PyQt5 import QtCore as qtc
from PyQt5.QtWidgets import QInputDialog, QFileDialog, QDialog
import sys

class projectWidget(qtw.QWidget):
    
    def __init__(self, *args, **kwargs):

        super().__init__(*args, **kwargs)

        self.ui = Ui_rproject()
        
        self.ui.setupUi(self)
        
        self.ui.browsefile.clicked.connect(self.open_dialog_box)
        
        self.ui.project.clicked.connect(self.printfile)
    
    def open_dialog_box(self):
        self.filename = QFileDialog.getOpenFileName()
        self.ui.inputedit.setText(self.filename[0])
        
        
    def printfile(self):
                
        if len(self.ui.outputedit.text()) > 8 or len(self.ui.outputedit.text()) < 4:
            qtw.QMessageBox.critical(self, 'Error', 'Please check EPSG Code input')
        elif self.ui.outputedit.text().isalpha():
            qtw.QMessageBox.critical(self, 'Error', 'Input Valid EPSG Code')
        else:
            src = self.filename[0]
            out = int(self.ui.outputedit.text())
            name = self.ui.outfileedit.text()                        
            outp = reproject_script.reproject(src, out, name)
            outp.runproject()
            qtw.QMessageBox.information(self, 'Success', 'Shapefile has been reprojected')
        

          
        
        
if __name__ == '__main__':
    
    app = qtw.QApplication(sys.argv)
    
    widget = projectWidget()
    
    widget.show()

    sys.exit(app.exec_())        
    