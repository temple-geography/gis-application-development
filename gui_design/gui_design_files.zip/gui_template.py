import sys
from PyQt5 import QtWidgets as qtw
from PyQt5 import QtCore as qtc
from PyQt5 import QtGui as qtg        

class firstWidget(qtw.QWidget):
    
    def __init__(self, *args, **kwargs):
        # you need to run the following line anytime you override init on a Qt object
        #this calls the parent objects init method
        super().__init__(*args, **kwargs)


        # functionaily goes here

        


if __name__ == '__main__':
    
    # management layer for app, this runs the event loop
    app = qtw.QApplication(sys.argv)
    
    # create widget instance
    widget = firstWidget()
    
    # call show method of QWidget
    widget.show()
    
    # call exec method of QApplication, reason for underscore is bc exec is a reserved python keyword
    sys.exit(app.exec_())
    