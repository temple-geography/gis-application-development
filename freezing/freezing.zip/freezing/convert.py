def to_celsius(temp):
    return (temp - 32) * 5/9

def to_fahrenheit(temp):
    return (temp * 9/5) + 32

choose = input("Fahrenheit to Celsius (F) or Celsius to Fahrenheit (C): ")

if choose.lower() == 'f':
    test = float(input("Enter degrees: "))
    print(to_celsius(test))
else:
    test = float(input("Enter degrees: "))
    print(to_fahrenheit(test))


end = input("Press Enter to Exit")