import geopandas as gpd
from matplotlib import pyplot as plt
import pandas as pd
import mapclassify as mc


def arealwt(source, target, statistic):
    source = gpd.read_file(source)
    target = gpd.read_file(target)
    target['division'] = target.index
    source['source_area'] = source.geometry.area
    joined1 = gpd.overlay(source, target, how = 'intersection')
    joined1['area'] = joined1.geometry.area
    joined1["AREAL_WT"] = joined1['area'] / joined1['source_area']
    joined1["EST"] = joined1["AREAL_WT"] * joined1[statistic]
    results = joined1[['division', "EST"]].groupby('division').sum()
    final = pd.merge(target, results, on='division')
    fig, ax = plt.subplots(1, figsize=(8, 8))
    return final.plot(column='EST', 
           cmap='YlGnBu', 
           edgecolor='0.5',
           ax = ax,
           linewidth=0.5,
           legend=True,
           k=4, 
           scheme='quantiles')



